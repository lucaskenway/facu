document.getElementById("formContato").addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const mensagem = document.getElementById("mensagem").value.trim();
    const status = document.getElementById("status");

    if (nome && email && mensagem) {
        // Exibe os dados no console do navegador
        console.log("Dados enviados:");
        console.log("Nome:", nome);
        console.log("Email:", email);
        console.log("Mensagem:", mensagem);

        status.textContent = "Mensagem enviada com sucesso!";
        status.style.color = "green";
        this.reset(); // limpa o formulário
    } else {
        status.textContent = "Por favor, preencha todos os campos.";
        status.style.color = "red";
    }
});
