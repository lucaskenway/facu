/* === script.js === */
document.addEventListener('DOMContentLoaded', function () {
  const input = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');
  const messages = document.getElementById('chat-messages');

  function responder(mensagem) {
    const msg = mensagem.toLowerCase();
    let respostaBot;

    if (msg.includes("cadastro")) {
      respostaBot = "Claro, papai ou mamãe! Para realizar o cadastro do seu(a) filho(a):<br>1️⃣ Clique na aba 🏫 Cadastro no topo da página.<br>2️⃣ Preencha todos os campos com os dados da criança e responsáveis.<br>3️⃣ Após preencher tudo, clique no botão 'Enviar'.<br>Se precisar de ajuda com algum campo, estou aqui! 😊";
    } else if (msg.includes("boletos")) {
      respostaBot = "Para acessar os boletos escolares:<br>1️⃣ Clique na aba 💳 Boletos no menu principal.<br>2️⃣ Você verá uma lista com os boletos disponíveis.<br>3️⃣ Clique no botão 'Gerar' ou 'Baixar' para acessar o boleto.<br>Qualquer dúvida, posso orientar!";
    } else if (msg.includes("relatório")) {
      respostaBot = "Os relatórios mensais são acessados assim:<br>1️⃣ Vá até a aba 📊 Relatórios.<br>2️⃣ Selecione o mês desejado.<br>3️⃣ O relatório será exibido ou poderá ser baixado em PDF.<br>Estamos aqui para manter vocês bem informados! ❤️";
    } else if (msg.includes("professor")) {
      respostaBot = "Para conhecer nossos professores:<br>1️⃣ Clique na aba 👨‍🏫 Professores.<br>2️⃣ Você verá a lista com nome, disciplina e horário de atendimento de cada professor.<br>3️⃣ Em breve, haverá um botão de contato direto também!";
    } else if (msg.includes("presença") || msg.includes("nota")) {
      respostaBot = "Para acompanhar presença e notas do seu filho ou filha:<br>1️⃣ Vá até a aba 📚 Presença & Notas.<br>2️⃣ Você verá uma tabela com os dias letivos e respectivas presenças.<br>3️⃣ As notas estarão ao lado de cada disciplina, atualizadas pelos professores.<br>Transparência e cuidado com a educação! 💙";
    } else if (msg.includes("horário") || msg.includes("atendimento")) {
      respostaBot = "Nosso horário de atendimento é de segunda a sexta-feira, das 8h às 17h.<br>Estamos sempre disponíveis para apoiar sua família nesse período!";
    } else if (msg.includes("oi") || msg.includes("olá") || msg.includes("bom dia") || msg.includes("boa tarde")) {
      respostaBot = "Olá, querido(a) responsável! 🤗 Seja muito bem-vindo(a)! Como posso te ajudar hoje com o cuidado do seu filho ou filha?";
    } else if (msg.includes("matrícula") || msg.includes("inscrição")) {
      respostaBot = "A matrícula funciona assim:<br>1️⃣ Clique na aba 🏫 Cadastro.<br>2️⃣ Preencha os dados do aluno e dos pais/responsáveis.<br>3️⃣ Clique em 'Enviar'.<br>4️⃣ Aguarde o contato da escola com a confirmação e orientações finais.<br>Se quiser, posso te guiar passo a passo!";
    } else if (msg.includes("ajuda")) {
      respostaBot = "Claro, estou aqui para ajudar! 😊 Você pode perguntar sobre:<br>- Como fazer matrícula<br>- Onde ver boletos<br>- Como acessar relatórios<br>- Onde estão as notas e presença<br>- Contato com professores<br>É só digitar sua dúvida com carinho!";
    } else {
      respostaBot = "Desculpe, ainda não entendi bem sua dúvida. Tente perguntar, por exemplo: 'Como vejo as notas?', 'Onde está o boletos?', ou 'Como fazer a matrícula?'. Estou aqui para ajudar com muito carinho! 💖";
    }

    messages.innerHTML += `<div class='bot-msg'>${respostaBot}</div>`;
    messages.scrollTop = messages.scrollHeight;
  }

  if (sendBtn) {
    sendBtn.addEventListener('click', () => {
      const userText = input.value.trim();
      if (userText) {
        messages.innerHTML += `<div class='user-msg'>${userText}</div>`;
        input.value = '';
        setTimeout(() => responder(userText), 500);
      }
    });
  }
});