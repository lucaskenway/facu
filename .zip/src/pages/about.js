
function About() {
  return (
    <main >

      <h2> Sobre Empresa</h2>

    </main>
  );
}

export default About;