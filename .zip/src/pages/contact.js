const Contact = () => {
  return(
    <main>
      <h2>Contato</h2>
    </main>
  )
}

export default Contact;