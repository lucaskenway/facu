export default function Home() {

return (
  <main >

      <h2> Bem Vindo</h2>

    </main>
  );
}
