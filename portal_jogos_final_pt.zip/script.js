
document.querySelectorAll(".btn").forEach(button => {
    button.addEventListener("click", () => {
        alert("Mais opções em breve!");
    });
});
